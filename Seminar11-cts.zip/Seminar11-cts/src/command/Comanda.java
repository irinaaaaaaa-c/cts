package command;

public interface Comanda {
    public void executa();
}
